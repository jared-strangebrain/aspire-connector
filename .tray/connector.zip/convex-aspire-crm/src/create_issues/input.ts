export type CreateIssuesInput = { body: unknown };
