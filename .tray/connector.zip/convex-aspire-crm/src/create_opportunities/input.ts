export type CreateOpportunitiesInput = { body: unknown };
