export type RawHttpOutput = unknown;
