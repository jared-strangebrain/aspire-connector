export const globalConfigHttp: any = {};
