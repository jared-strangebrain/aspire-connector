export type ListContactTypesOutput = unknown;
