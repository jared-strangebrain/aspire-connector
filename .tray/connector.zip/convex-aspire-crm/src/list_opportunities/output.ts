export type ListOpportunitiesOutput = unknown;
