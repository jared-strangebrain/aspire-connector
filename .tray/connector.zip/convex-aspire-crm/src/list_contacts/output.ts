export type ListContactsOutput = unknown;
