export type CreateContactsInput = { body: unknown };
