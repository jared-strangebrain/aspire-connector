export type CreateContactsOutput = Record<string, unknown>;
