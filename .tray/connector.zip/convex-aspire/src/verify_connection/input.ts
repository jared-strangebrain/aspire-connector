export type VerifyConnectionInput = { $top?: number; $select?: string };
