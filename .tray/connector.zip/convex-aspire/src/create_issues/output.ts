export type CreateIssuesOutput = string;
