export type CreateOpportunitiesOutput = string;
