/* eslint-disable import/extensions */
import { OperationHandlerSetup } from '@trayio/cdk-dsl/connector/operation/OperationHandlerSetup';
import { OperationHandlerResult } from '@trayio/cdk-dsl/connector/operation/OperationHandler';
import _ from 'lodash';
import { Endpoint, FullUrl, RawHttpRequestInput } from './input';
import { RawHttpRequestOutput } from './output';
import { isValidEndpoint, isValidUrl } from './urlValidations';
import { globalConfigHttp } from '../GlobalConfig';

export const RawHttpRequestCdkHandler = OperationHandlerSetup.configureHandler<
	any | never,
	RawHttpRequestInput,
	RawHttpRequestOutput
>((handler) =>
	handler
		.addInputValidation((inputValidation) =>
			inputValidation
				.condition((ctx, input) => {
					const url = (<FullUrl>input.url).fullUrl;
					if (url === undefined) {
						return true;
					}
					return isValidUrl(url);
				})
				.errorMessage(
					() => 'please provide a valid url starting with http:// or https://'
				)
		)
		.addInputValidation((inputValidation) =>
			inputValidation
				.condition((ctx, input) => {
					const { endpoint } = <Endpoint>input.url;
					if (endpoint === undefined) {
						return true;
					}
					return isValidEndpoint(endpoint);
				})
				.errorMessage(
					() =>
						'Endpoint will be appended onto the base URL defined by the connector. Please use `Full URL` to specify a URL starting with `http://` or `https://`.'
				)
		)
		.withGlobalConfiguration(globalConfigHttp)
		.usingHttp((http) =>
			http
				.get('')
				.handleRequest((ctx, input, request) => {
					let transformedRequest = request
						.withMethod(input.method)
						.withUrl(
							(<FullUrl>input.url).fullUrl
								? (<FullUrl>input.url).fullUrl
								: `${request.path}${(<Endpoint>input.url).endpoint}`
						);

					// Add query parameters to the request
					for (const [key, value] of Object.entries(input.queryParams ?? {})) {
						transformedRequest = transformedRequest.addQueryString(
							key,
							<string>value
						);
					}

					// Add headers to the request
					for (const [key, value] of Object.entries(input.headers ?? {})) {
						transformedRequest = transformedRequest.addHeader(
							key,
							<string>value
						);
					}

					// Add body to the request
					const bodyType = Object.keys(input.body)[0];
					const body = input.body[bodyType as keyof typeof input.body]; // Add type assertion to fix the problem

					if (bodyType === 'raw') {
						return _.isObject(body)
							? transformedRequest.withBodyAsJson(body)
							: transformedRequest.withBodyAsText(body);
					}

					if (bodyType === 'form_urlencoded') {
						return transformedRequest.withBodyAsFormUrlEncoded(body);
					}

					if (bodyType === 'binary') {
						return transformedRequest.withBodyAsFile(body);
					}

					return transformedRequest.withoutBody();
				})
				.handleResponse((ctx, input, response) =>
					response.parseWithBodyAsJson((body) =>
						OperationHandlerResult.success({
							status: response.getStatusCode(),
							headers: response.getHeaders(),
							body,
						})
					)
				)
		)
);
