export type PropertiesCreateOutput = number;
