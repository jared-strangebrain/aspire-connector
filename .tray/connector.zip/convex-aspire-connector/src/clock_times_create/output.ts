export type ClockTimesCreateOutput = number;
