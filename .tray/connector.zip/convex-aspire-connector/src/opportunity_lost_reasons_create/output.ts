export type OpportunityLostReasonsCreateOutput = Record<string, never>;
