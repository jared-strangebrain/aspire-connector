export type PropertyContactsCreateOutput = number;
