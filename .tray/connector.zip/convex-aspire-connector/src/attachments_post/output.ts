export type AttachmentsPostOutput = string;
