export type ReceiptsApproveReceiptOutput = boolean;
