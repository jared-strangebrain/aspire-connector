import { tokenRefreshHandler } from './handler';

describe.skip('#token_refresh handler', () => {
  it('should refresh the access token', async () => {
    expect(true).toBe(true);
  });
});
