export type TokenRefreshInput = {
  // No input required - the refresh token is taken from ctx.auth.user
};

