export type ContactCustomFieldsUpdateOutput = number;
