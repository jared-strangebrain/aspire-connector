export type EquipmentReadingLogsCreateOutput = number;
