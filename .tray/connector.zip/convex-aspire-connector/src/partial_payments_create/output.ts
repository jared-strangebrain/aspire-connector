export type PartialPaymentsCreateOutput = string;
