export type ItemAllocationsCreateOutput = boolean;
