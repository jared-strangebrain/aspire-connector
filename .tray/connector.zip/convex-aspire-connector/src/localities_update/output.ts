export type LocalitiesUpdateOutput = number;
