export type PropertyCustomFieldsUpdateOutput = number;
