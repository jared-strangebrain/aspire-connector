export type ContactCustomFieldsCreateOutput = number;
