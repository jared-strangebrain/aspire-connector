export const isValidUrl = (urlString: string) => {
	try {
		return Boolean(new URL(urlString));
	} catch (e) {
		return false;
	}
};

export const isValidEndpoint = (endpoint: string) =>
	['http://', 'https://'].every((prefix) => endpoint.indexOf(prefix) !== 0);
