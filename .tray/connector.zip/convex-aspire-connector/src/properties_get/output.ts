export interface Property {
  PropertyID?: number;
  PropertyStatusID?: number;
  PropertyStatusName?: string;
  BranchID?: number;
  BranchName?: string;
  BranchCode?: string;
  AccountOwnerContactID?: number;
  AccountOwnerContactName?: string;
  ProductionManagerContactID?: number;
  ProductionManagerContactName?: string;
  PropertyAddressID?: number;
  CountyID?: number;
  PropertyAddressLine1?: string;
  PropertyAddressLine2?: string;
  PropertyAddressCity?: string;
  PropertyAddressStateProvinceCode?: string;
  PropertyAddressZipCode?: string;
  LocalityID?: number;
  LocalityName?: string;
  IndustryID?: number;
  IndustryName?: string;
  LeadSourceID?: number;
  LeadSourceName?: string;
  TaxJurisdictionID?: number;
  TaxJurisdictionName?: string;
  PropertyGroupID?: number;
  ActiveOpportunityID?: number;
  CompetitorID?: number;
  PropertyGroupName?: string;
  PropertyName?: string;
  PropertyNameAbr?: string;
  SequenceNumber?: string;
  ProductionNote?: string;
  Active?: boolean;
  EmailInvoice?: boolean;
  Budget?: number;
  Note?: string;
  CreatedByUserID?: number;
  CreatedByUserName?: string;
  CreatedDate?: string;
  GEOPerimeter?: number;
  GEOLocationLatitude?: number;
  GEOLocationLongitude?: number;
  PaymentTermsID?: number;
  PaymentTermsName?: string;
  SeparateInvoices?: boolean;
  Website?: string;
  ModifiedByUserID?: number;
  ModifiedByUserName?: string;
  ModifiedDate?: string;
  DragDropGeoLocation?: boolean;
  GPSUpdated?: boolean;
  GPSGeofenceID?: string;
  SnowNote?: string;
  EarliestOpportunityWonDate?: string;
  PropertyContacts?: any[];
  PropertyTags?: any[];
  PropertyTakeoffItems?: any[];
  CollectionNotes?: string;
  IntegrationID?: string;
  PropertyTypeID?: number;
  PropertyType?: string;
  PropertyTypeIntegrationCode?: string;
}

export type PropertiesGetOutput = {
  /**
   * @title Properties
   * @description List of properties returned from the Aspire API
   */
  properties: Property[];
};
