export type OpportunityTagsDeleteOutput = number;
