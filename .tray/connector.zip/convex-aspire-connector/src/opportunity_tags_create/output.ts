export type OpportunityTagsCreateOutput = number;
