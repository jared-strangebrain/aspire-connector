export type PropertyContactsUpdateOutput = number;
