export type LocalitiesCreateOutput = number;
