export type PropertiesUpdateOutput = number;
