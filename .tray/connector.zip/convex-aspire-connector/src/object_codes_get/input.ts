export type ObjectCodesGetInput = {
  // Original parameter name: api-version
  api_version?: string;
};
