export type CatalogItemsUpdateOutput = number;
