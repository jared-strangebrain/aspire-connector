export interface Output {
  CompanyID?: number;
}

export type CompaniesPutOutput = Output;
