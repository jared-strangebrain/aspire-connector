export type AttachmentsNewLinkOutput = string;
