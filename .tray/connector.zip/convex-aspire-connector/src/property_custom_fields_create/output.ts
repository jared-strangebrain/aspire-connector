export type PropertyCustomFieldsCreateOutput = number;
