export type IssuesCreateOutput = string;
