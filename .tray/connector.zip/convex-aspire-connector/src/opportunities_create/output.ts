export type OpportunitiesCreateOutput = string;
