export type VerifyConnectionOutput = unknown;
