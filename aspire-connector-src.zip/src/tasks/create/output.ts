export type CreateTasksOutput = string;
