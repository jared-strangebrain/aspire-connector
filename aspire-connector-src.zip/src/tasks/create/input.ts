export type CreateTasksInput = { body: unknown };
