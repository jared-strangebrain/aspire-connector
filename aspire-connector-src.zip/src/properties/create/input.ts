export type CreatePropertiesInput = { body: unknown };
