export type CreatePropertiesOutput = string;
