export type ListPropertiesOutput = unknown;
