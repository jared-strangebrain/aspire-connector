export type ListBranchesOutput = unknown;
