export type CreateContactsOutput = string;
