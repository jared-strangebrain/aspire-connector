export type SendMessageOutput = {
	ok: boolean
};
