export type ListChannelsDdlOutput = {
  result: {
    text: string;
    value: string;
  }[];
};
