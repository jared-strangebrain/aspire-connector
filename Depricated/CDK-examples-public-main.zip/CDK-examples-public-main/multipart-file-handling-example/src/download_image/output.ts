import { FileReference } from '@trayio/cdk-dsl/dist/connector/operation/OperationHandler';

export type DownloadImageOutput = {
	file: FileReference;
};
