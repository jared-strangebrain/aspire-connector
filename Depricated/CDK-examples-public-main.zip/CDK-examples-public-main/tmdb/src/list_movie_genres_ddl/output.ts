import { DDLOperationOutput } from "@trayio/cdk-dsl/connector/operation/OperationHandler"

export type ListMovieGenresDdlOutput = DDLOperationOutput<number>