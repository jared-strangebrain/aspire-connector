export type GetMovieGenresInput = {};
