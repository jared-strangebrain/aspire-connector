export type GetTopRatedMoviesInput = {};
