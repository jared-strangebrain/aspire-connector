export type GetPostInput = {
	id: number;
	email: string;
};
