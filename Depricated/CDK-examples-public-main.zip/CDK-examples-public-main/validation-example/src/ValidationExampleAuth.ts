export type ValidationExampleAuth = any; // No Authentication
