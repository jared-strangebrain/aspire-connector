export type ErrorHandlingExampleAuth = never; // No Authentication
