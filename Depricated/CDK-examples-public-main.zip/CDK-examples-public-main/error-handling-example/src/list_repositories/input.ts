export type ListRepositoriesInput = {
	id: number;
};
