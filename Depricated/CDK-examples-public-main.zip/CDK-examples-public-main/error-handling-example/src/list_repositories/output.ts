export type ListRepositoriesOutput = {
	id: number;
	title: string;
};
