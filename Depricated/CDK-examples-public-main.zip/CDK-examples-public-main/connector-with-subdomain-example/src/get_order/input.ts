export type GetOrderInput = {
  id: number;
};
