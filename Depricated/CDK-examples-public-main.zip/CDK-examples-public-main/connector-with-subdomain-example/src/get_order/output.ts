export type GetOrderOutput = {
  order: {
    id: number;
    name: string;
  };
};
