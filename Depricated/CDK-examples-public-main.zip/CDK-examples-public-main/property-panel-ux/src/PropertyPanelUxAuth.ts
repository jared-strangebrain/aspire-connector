export type PropertyPanelUxAuth = never; // No Authentication
