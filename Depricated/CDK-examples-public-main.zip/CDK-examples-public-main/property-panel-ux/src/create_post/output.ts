export type CreatePostOutput = {
	id: number;
	title: string;
	body: string;
	userId: number;
};
