export type GetPostOutput = {
	id: number;
	title: string;
};
