import { FileReference } from "@trayio/cdk-dsl/connector/operation/OperationHandler";

export type DownloadFileFromUrlOutput = {
  file: FileReference;
};
