import { FileReference } from "@trayio/cdk-dsl/connector/operation/OperationHandler";

export type UploadFileToFilebinInput = {
  file: FileReference;
};
