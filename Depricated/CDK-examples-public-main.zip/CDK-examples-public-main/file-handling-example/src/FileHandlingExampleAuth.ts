export type FileHandlingExampleAuth = never; // No Authentication
