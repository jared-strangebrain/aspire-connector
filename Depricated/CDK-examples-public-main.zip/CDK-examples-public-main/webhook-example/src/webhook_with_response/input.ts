export type WebhookWithResponseInput = {};
