export type MyTriggerAuth = never
