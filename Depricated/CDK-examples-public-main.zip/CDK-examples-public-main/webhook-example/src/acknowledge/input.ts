export type AcknowledgeInput = {};
