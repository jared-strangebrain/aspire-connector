export type CreateOrUpdatePostInput = {
  id?: number;
  userId?: number;
  title?: string;
  body?: string;
};
