export type ConvertJsonToXmlInput = {
  json: string;
};
