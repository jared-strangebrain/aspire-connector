export type ConvertJsonToXmlOutput = {
  output: string;
};
