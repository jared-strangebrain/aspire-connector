export type CompositeExampleAuth = never; // No Authentication
