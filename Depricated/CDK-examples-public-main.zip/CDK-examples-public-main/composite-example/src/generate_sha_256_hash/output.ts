export type GenerateSha256HashOutput = {
  input: string;
  output: string;
};
