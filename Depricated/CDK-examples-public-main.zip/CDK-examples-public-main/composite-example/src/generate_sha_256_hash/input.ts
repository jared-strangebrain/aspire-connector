export type GenerateSha256HashInput = {
  value: string;
};
