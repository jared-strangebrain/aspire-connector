export type TokenRequestInput = {
  auth_form_input: {
    client_id: string;
    client_secret: string;
    account_id: string;
  };
};
