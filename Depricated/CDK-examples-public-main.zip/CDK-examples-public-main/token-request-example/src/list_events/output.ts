export type ListEventsOutput = {
	links: Array<object>;
};
