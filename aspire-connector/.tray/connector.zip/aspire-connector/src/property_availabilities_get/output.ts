export type PropertyAvailabilitiesGetOutput = any;
