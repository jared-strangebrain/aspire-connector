export type JobsGetOutput = any;
