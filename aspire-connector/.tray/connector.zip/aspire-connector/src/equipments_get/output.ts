export type EquipmentsGetOutput = any;
