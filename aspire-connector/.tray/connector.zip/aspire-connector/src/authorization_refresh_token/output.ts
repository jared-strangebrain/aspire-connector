export type AuthorizationRefreshTokenOutput = any;
