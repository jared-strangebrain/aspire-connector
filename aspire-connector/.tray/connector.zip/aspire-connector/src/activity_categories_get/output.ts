export type ActivityCategoriesGetOutput = any;
