export type PropertyCustomFieldDefinitionsGetOutput = any;
