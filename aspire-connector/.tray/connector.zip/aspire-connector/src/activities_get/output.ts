export type ActivitiesGetOutput = any;
