export type ContactsGetOutput = any;
