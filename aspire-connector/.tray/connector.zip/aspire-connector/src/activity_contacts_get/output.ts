export type ActivityContactsGetOutput = any;
