export type BankDepositsGetOutput = any;
