export type AuthorizationAuthenticateApiRequestOutput = any;
