export type DivisionsGetOutput = any;
