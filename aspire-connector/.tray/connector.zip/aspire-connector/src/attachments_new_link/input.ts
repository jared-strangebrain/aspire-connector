export type AttachmentsNewLinkInput = {
  link?: string;
  // Original parameter name: api-version
  api_version?: string;
};
