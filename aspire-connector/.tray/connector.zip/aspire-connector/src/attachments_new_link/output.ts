export type AttachmentsNewLinkOutput = any;
