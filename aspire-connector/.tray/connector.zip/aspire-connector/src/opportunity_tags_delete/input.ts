export type OpportunityTagsDeleteInput = {
  id: number;
  // Original parameter name: api-version
  api_version?: string;
};
