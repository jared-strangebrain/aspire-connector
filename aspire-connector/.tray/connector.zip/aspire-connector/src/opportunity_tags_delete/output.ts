export type OpportunityTagsDeleteOutput = any;
