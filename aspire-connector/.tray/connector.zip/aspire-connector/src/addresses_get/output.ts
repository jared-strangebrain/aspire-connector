export type AddressesGetOutput = any;
