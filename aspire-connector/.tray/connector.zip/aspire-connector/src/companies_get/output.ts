export type CompaniesGetOutput = any;
