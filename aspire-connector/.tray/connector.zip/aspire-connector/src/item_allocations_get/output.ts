export type ItemAllocationsGetOutput = any;
