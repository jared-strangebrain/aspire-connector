export type PaySchedulesGetOutput = any;
