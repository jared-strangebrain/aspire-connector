export type AttachmentsGetOutput = any;
