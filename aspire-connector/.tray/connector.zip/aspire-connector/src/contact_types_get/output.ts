export type ContactTypesGetOutput = any;
