export type OpportunitiesGetOutput = any;
