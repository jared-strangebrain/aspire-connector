export type PropertyContactsGetOutput = any;
