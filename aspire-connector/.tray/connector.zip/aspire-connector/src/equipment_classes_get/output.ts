export type EquipmentClassesGetOutput = any;
