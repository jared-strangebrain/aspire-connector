export type EquipmentManufacturersGetOutput = any;
