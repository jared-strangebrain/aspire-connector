export type AttachmentTypesGetOutput = any;
