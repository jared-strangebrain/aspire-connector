export type AttachmentTypesGetInput = {
  // Original parameter name: api-version
  api_version?: string;
};
