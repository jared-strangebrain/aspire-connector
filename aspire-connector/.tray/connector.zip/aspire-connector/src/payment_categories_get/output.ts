export type PaymentCategoriesGetOutput = any;
