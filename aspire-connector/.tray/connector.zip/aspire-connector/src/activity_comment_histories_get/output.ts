export type ActivityCommentHistoriesGetOutput = any;
