export type InvoicesGetOutput = any;
