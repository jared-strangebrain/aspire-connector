export type CertificationsGetOutput = any;
