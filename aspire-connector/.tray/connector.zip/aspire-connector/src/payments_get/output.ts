export type PaymentsGetOutput = any;
