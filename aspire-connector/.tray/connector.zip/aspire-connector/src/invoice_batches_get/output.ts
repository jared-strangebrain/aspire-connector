export type InvoiceBatchesGetOutput = any;
