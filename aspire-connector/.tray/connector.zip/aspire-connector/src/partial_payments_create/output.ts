export type PartialPaymentsCreateOutput = any;
