export type OpportunityStatusesGetOutput = any;
