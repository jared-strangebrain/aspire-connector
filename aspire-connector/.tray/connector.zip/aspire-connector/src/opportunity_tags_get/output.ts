export type OpportunityTagsGetOutput = any;
