export type CatalogItemCategoriesGetOutput = any;
