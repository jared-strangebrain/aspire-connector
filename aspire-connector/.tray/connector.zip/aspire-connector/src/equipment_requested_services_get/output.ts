export type EquipmentRequestedServicesGetOutput = any;
