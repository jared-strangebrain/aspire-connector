export type PayRatesGetOutput = any;
