export type IssuesCreateOutput = any;
