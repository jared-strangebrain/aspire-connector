export type DivisionIntegrationCodesGetOutput = any;
