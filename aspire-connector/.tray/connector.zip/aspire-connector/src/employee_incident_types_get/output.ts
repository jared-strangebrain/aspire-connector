export type EmployeeIncidentTypesGetOutput = any;
