export type ContactCustomFieldsGetOutput = any;
