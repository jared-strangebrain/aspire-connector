export type ContactCustomFieldDefinitionsGetOutput = any;
