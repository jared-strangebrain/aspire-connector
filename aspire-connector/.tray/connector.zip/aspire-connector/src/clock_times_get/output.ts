export type ClockTimesGetOutput = any;
