export type OpportunityServicesGetOutput = any;
