export type CertificationTypesGetOutput = any;
