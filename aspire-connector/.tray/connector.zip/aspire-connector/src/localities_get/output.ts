export type LocalitiesGetOutput = any;
