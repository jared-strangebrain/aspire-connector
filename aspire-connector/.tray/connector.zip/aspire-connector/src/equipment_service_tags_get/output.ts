export type EquipmentServiceTagsGetOutput = any;
