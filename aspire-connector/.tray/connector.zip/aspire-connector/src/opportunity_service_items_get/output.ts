export type OpportunityServiceItemsGetOutput = any;
