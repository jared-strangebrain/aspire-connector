export type ObjectCodesGetOutput = any;
