export type EquipmentSizesGetOutput = any;
