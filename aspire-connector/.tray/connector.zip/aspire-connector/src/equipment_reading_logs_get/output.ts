export type EquipmentReadingLogsGetOutput = any;
