export type InvoiceTaxesGetOutput = any;
