export type JobStatusesGetOutput = any;
