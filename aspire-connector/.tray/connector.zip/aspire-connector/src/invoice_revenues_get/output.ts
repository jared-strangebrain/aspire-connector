export type InvoiceRevenuesGetOutput = any;
