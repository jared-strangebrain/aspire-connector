export type OpportunityLostReasonsGetOutput = any;
