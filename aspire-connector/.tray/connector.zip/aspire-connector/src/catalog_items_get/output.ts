export type CatalogItemsGetOutput = any;
