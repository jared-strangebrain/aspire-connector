export type PaymentTermsGetOutput = any;
