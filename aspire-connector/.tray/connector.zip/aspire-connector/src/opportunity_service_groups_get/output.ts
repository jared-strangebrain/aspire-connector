export type OpportunityServiceGroupsGetOutput = any;
