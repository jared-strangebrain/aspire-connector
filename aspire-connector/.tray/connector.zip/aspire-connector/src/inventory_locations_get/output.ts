export type InventoryLocationsGetOutput = any;
