export type EquipmentServiceLogsGetOutput = any;
