export type EmployeeIncidentsGetOutput = any;
