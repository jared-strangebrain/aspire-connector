export type EquipmentDisposalReasonsGetOutput = any;
