export type EquipmentModelServiceSchedulesGetOutput = any;
