export type PropertiesGetOutput = any;
