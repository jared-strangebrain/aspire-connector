export type OpportunityServiceKitItemsGetOutput = any;
