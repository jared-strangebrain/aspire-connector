export type CatalogItemsCreateOutput = number;
