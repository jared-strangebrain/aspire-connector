import type { TokenOperationHandlerAuth } from "@trayio/cdk-dsl/connector/operation/OperationHandler";

/**
 * User authentication context (populated after #token_request)
 * Contains the Bearer token from Aspire API.
 * 
 * Based on Aspire API documentation:
 * https://guide.youraspire.com/apidocs/authentication-authorization-1
 * 
 * - Tokens are valid for 24 hours
 * - POST /Authorization returns Token and RefreshToken
 * - POST /Authorization/RefreshToken can refresh the token
 */
export type AspireUserAuth = {
  /** Bearer token from Aspire API (valid for 24 hours) */
  access_token: string;
  /** Refresh token to obtain a new access token */
  refresh_token?: string;
};

/**
 * App authentication configuration
 * Contains the credentials from the authentication form
 */
export type AspireAppAuth = {
  /** Aspire API Client ID */
  client_id: string;
  /** Aspire API Client Secret */
  client_secret: string;
  /** Selected environment (demo/sandbox/production) */
  environment: "production" | "sandbox" | "demo";
};

/**
 * Aspire Connector Authentication type
 * Uses Tray's token-based authentication with automatic token management
 */
export type AspireConnectorAuth = TokenOperationHandlerAuth<
  AspireUserAuth,
  AspireAppAuth
>;

// Helper functions for authentication

/**
 * Get the base URL for a given environment
 * 
 * @param env - The Aspire environment (production, sandbox, or demo)
 * @returns The base URL for API requests
 */
export function getBaseUrlForEnvironment(env: "production" | "sandbox" | "demo"): string {
  switch (env) {
    case "production":
      return "https://cloud-api.youraspire.com";
    case "sandbox":
      return "https://cloudsandbox-api.youraspire.com";
    case "demo":
      return "https://clouddemo-api.youraspire.com";
    default:
      return "https://clouddemo-api.youraspire.com"; // Default to demo
  }
}
