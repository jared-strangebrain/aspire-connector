export type ObjectCodesGetOutput = string[];
