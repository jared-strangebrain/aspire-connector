export type ContactsUpdateOutput = string;
