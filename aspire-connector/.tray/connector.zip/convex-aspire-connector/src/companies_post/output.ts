export interface Output {
  CompanyID?: number;
}

export type CompaniesPostOutput = Output;
