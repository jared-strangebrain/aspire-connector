import { OperationHandlerSetup } from '@trayio/cdk-dsl/connector/operation/OperationHandlerSetup';
import { OperationHandlerResult } from '@trayio/cdk-dsl/connector/operation/OperationHandler';
import { AspireConnectorAuth, getBaseUrlForEnvironment } from '../AspireConnectorAuth';
import { TokenRequestInput } from './input';
import { TokenRequestOutput, AspireTokenResponse } from './output';

/**
 * Token request handler for Aspire API
 * 
 * Based on Aspire API documentation:
 * https://guide.youraspire.com/apidocs/authentication-authorization-1
 * 
 * This operation authenticates with Aspire using Client ID and Secret
 * and returns a Bearer token valid for 24 hours.
 * 
 * Endpoint: POST {base_url}/Authorization
 * Request Body: { ClientId, Secret }
 * Response: { Token, RefreshToken }
 */
export const tokenRequestHandler = OperationHandlerSetup.configureHandler<
  AspireConnectorAuth,
  TokenRequestInput,
  TokenRequestOutput
>((handler) =>
  handler.usingComposite(async (ctx, input, invoke) => {
    // Get the correct base URL based on environment selection
    const baseUrl = getBaseUrlForEnvironment(input.auth_form_input.environment);
    const url = `${baseUrl}/Authorization`;
    
    // Make authentication request to Aspire API
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ClientId: input.auth_form_input.client_id,
        Secret: input.auth_form_input.client_secret
      })
    });
    
    // Handle error responses
    if (!response.ok) {
      const errorText = await response.text().catch(() => '');
      return OperationHandlerResult.failure({
        _tag: 'ConnectorError',
        message: `Aspire authentication failed (${response.status}): ${errorText}`
      });
    }
    
    // Parse response
    const data: AspireTokenResponse = await response.json().catch(() => ({}) as any);
    
    // Aspire returns "Token" and "RefreshToken" (not standard OAuth2 names)
    const accessToken = data.Token;
    const refreshToken = data.RefreshToken;
    
    if (!accessToken) {
      return OperationHandlerResult.failure({
        _tag: 'ConnectorError',
        message: 'Aspire authentication response missing Token field'
      });
    }
    
    // Return in the format expected by Tray token-based authentication
    return OperationHandlerResult.success({
      status_code: response.status,
      headers: Object.fromEntries(response.headers.entries()),
      body: {
        // Store the access token (required)
        access_token: accessToken,
        // Store refresh token if provided
        refresh_token: refreshToken
      }
    });
  })
);
