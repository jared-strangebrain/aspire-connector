export type EquipmentReadingLogsUpdateOutput = number;
