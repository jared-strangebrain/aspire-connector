export type ItemAllocationsUpdateOutput = number;
