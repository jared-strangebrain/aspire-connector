export type ContactsCreateOutput = string;
